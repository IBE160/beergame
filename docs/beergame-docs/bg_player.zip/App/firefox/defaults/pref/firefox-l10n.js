//@line 36 "/cygdrive/c/builds/tinderbox/Fx-Mozilla1.8-Release/WINNT_5.2_Depend/mozilla/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/cygdrive/c/builds/tinderbox/Fx-Mozilla1.8-Release/WINNT_5.2_Depend/mozilla/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
