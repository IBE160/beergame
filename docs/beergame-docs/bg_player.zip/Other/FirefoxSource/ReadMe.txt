Firefox source code is available from the Firefox Portable page:
http://portableapps.com/apps/internet/firefox_portable